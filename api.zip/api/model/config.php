<?php
$db = [
    'host' => 'localhost',
    'username' => 'gamefire',
    'password' => 'gamefire2022',
    'db' => 'gamefire' 
];
?>